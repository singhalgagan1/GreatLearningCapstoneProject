# Adding imports required for data cleansing and visualization
import numpy as np
import pandas as pd
import random
import pickle
import os
import re
import matplotlib.pyplot as plt

# Flask utils
from flask import Flask, redirect, url_for, request, render_template
from werkzeug.utils import secure_filename
from gevent.pywsgi import WSGIServer
from flask import send_file

# Tensor flow imports
import tensorflow
from tensorflow import keras
from tensorflow.keras.models import Model, Sequential, model_from_json
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.metrics import Recall, Precision

# Adding imports for image prep
import pydicom #For displaying dcm images
import cv2
from PIL import Image
import base64

# Define a flask app
app = Flask(__name__)

@app.route('/', methods=['GET'])
def index():
    # Main page
    return render_template('index.html')

def Proprocess_ModelFromScratch(file_path, imageSize):
    # Read the input image file
    img = pydicom.read_file(file_path).pixel_array

    # Convert image to 3 channels
    img = np.stack([img] * 3, axis=2)
    
    # Resize image
    img = np.array(img).astype(np.uint8)
    img = cv2.resize(img, (imageSize, imageSize), interpolation = cv2.INTER_LINEAR)
    img = img.astype('uint32')
    return (img)

def Postprocess_ModelFromScratch(predict_image_arr, img):
    #Extract x1, y1 co-ordinates and width, height of bounding box
    x1, y1, width, height = int(predict_image_arr[0][0][0]), int(predict_image_arr[0][0][1]), int(predict_image_arr[0][0][2]), int(predict_image_arr[0][0][3])
    
    print ("\n+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
    print ("Predicted co-ordinates -> ", x1, y1, width, height)
    print ("Predicted target class -> ", np.round(predict_image_arr[1][0][0]).astype('uint32'))

    #Apply bounding box co-ordinates and draw lines for the bounding box
    y2 = y1 + height
    x2 = x1 + width
    img[y1:y1 + 1, x1:x2] = 1
    img[y2:y2 + 1, x1:x2] = 1
    img[y1:y2, x1:x1 + 1] = 1
    img[y1:y2, x2:x2 + 1] = 1
    return (img)

def cvt_2_base64(file_name):
    with open(file_name , "rb") as image_file :
        data = base64.b64encode(image_file.read())
    return data.decode('utf-8')

def dice_coefficient(y_true, y_pred):
    numerator = 2 * tensorflow.reduce_sum(y_true * y_pred)
    denominator = tensorflow.reduce_sum(y_true + y_pred)
    # reduce_sum(), computes the sum of elements across dimensions of a tensor.
    # Since the 2nd arg, i.e., axis of reduce_sum() is 'None', it reduces all dimensions, 
    # and a tensor with a single element is returned.
    
    return numerator / (denominator + tensorflow.keras.backend.epsilon())

def loss(y_true, y_pred):
    return binary_crossentropy(y_true, y_pred) - tensorflow.keras.backend.log(dice_coefficient(y_true, y_pred) + tensorflow.keras.backend.epsilon())
    
@app.route('/predict', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        # Get the file from post request
        f = request.files['filename']

        # Save the file to ./uploads
        basepath = os.path.dirname(__file__)
        file_path = os.path.join(
            basepath, 'uploads', secure_filename(f.filename))
        f.save(file_path)

        modelType = request.form['modelType']
        if (modelType == 'Model-From-Scratch'):
            imageSize = 128
        else:
            imageSize = 224
            
        img = Proprocess_ModelFromScratch(file_path, imageSize)

        # Load the saved model
        if (modelType == 'Model-From-Scratch'):
            savedModel_h5 = keras.models.load_model('./OD_Basic_ModelFromScratch_8k_final.h5')
        else:
            # Reading the model from JSON file
            with open('OD-MobileNetUnet.json', 'r') as json_file:
                json_savedModel = json_file.read()
            # Load the model architecture 
            savedModel_h5 = model_from_json(json_savedModel)
            # Reloading the trained weights
            savedModel_h5.load_weights('OD-MobileNetUnet-Weights.h5')
            
            np.random.seed(0)
            random.seed(0)
            tensorflow.random.set_seed(0)

            # Defining optimizer and compile
            optimizer = Adam(lr=0.001)
            savedModel_h5.compile(loss=loss, optimizer=optimizer, metrics=[dice_coefficient, Recall(), Precision()])
            
        # Do prediction
        image_array = np.array([img])
        
        if (modelType == 'Model-From-Scratch'):
            predict_image_arr = savedModel_h5.predict(image_array)
            img = Postprocess_ModelFromScratch(predict_image_arr, img)
        else:
            pred_image = savedModel_h5.predict(image_array)
            img = pred_image[0]
        
        # Convert and save the image
        im = Image.fromarray((img * 255).astype(np.uint8)).resize((imageSize, imageSize)).convert('RGB')

        if (modelType == 'Model-From-Scratch'):
            im.save('uploads/' + f.filename + '_fromScratch' + '.png')
            # For returning the saved file on the browser        
            base64_data = cvt_2_base64 ('uploads/' + f.filename + '_fromScratch' + '.png')
        else:
            im.save('uploads/' + f.filename + '_mobilenet_unet' + '.png')
            # for returning the saved file on the browser
            base64_data = cvt_2_base64 ('uploads/' + f.filename + '_mobilenet_unet' + '.png')

        print ("Model type chosen is -> ", modelType)
        print ("Prediction input filename -> ", f.filename)
        print ("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n")

        # return send_file('uploads/' + f.filename + '_predict_8k' + '.png', mimetype='image/gif')
    return base64_data
    
if __name__ == '__main__':
    app.run(debug=True)